import '../helper/constants.dart';

import './home_screen.dart';
import '../widgets/database_method.dart';
import 'package:flutter/material.dart';

import '../widgets/auth_form.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';



class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  //9FirebaseAuth _auth = FirebaseAuth.instance;
  var _isLoading = false;
  File? userImage;
  QuerySnapshot? snapShotUserInfo;

  //get password => null;

  //Submit AuthCredential Function

  Future<void> submitLogin(String? email, String? password) async {
    try {
      //HelperFunction.saveUserEmailSharedPreferences(email!);

      // DataBaseMethods().getUserByUsername(email).then((val) {
      //   snapShotUserInfo = val;
      //   HelperFunction.saveUserNameSharedPreferences(
      //       snapShotUserInfo!.docs[0]['username']);
      // });

      setState(() {
        _isLoading = true;
      });

      UserCredential userCredential;
      userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email!,
        password: password!,
      );

      DataBaseMethods().getUserByEmailId(email);

      //Constants.myName = await HelperFunction.getUserNameSharedPreferences();

      //HelperFunction.saveUserLoggedInSharedPreferences(true);

      Navigator.push(
          context, MaterialPageRoute(builder: (context) => HomeScreen()));
      
    } on FirebaseAuthException catch (error) {
      String? message = 'An error occured, please check your credentials!';

      if (error.message != null) {
        message = error.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message!),
          backgroundColor: Theme.of(context).errorColor,
        ),
      );
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> submitSignup(String? email, String? password, String? username,
      File? image, bool isLogin, BuildContext ctx) async {
    UserCredential userCredential;
    //HelperFunction helperFunction = new HelperFunction();
    try {
      setState(() {
        _isLoading = true;
      });

      Constants.myName = username!;
      
      //Constants.myName = DataBaseMethods().getUserByUsername(username);
      print(Constants.myName);

      

      userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email!, password: password!);

      final ref = FirebaseStorage.instance
          .ref()
          .child('user_image')
          .child(userCredential.user!.uid + '.jpg');

      await ref.putFile(image!).whenComplete(() => print('Image Upload'));

      final url = await ref.getDownloadURL();

      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user?.uid)
          .set({
        'username': username,
        'email': email,
        'imageUrl': url,
        'createdAt': Timestamp.now(),
        'uid': userCredential.user!.uid,
      });

      //HelperFunction.saveUserLoggedInSharedPreferences(true);

      Navigator.push(
          context, MaterialPageRoute(builder: (context) => HomeScreen()));
      
    } on FirebaseAuthException catch (error) {
      String? message = 'An error occured, please check your credentials!';

      if (error.message != null) {
        message = error.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message!),
          backgroundColor: Theme.of(ctx).errorColor,
        ),
      );
      setState(() {
        _isLoading = false;
      });
    } catch (error) {
      print(error);
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: AuthForm(submitSignup, _isLoading, submitLogin),
    );
  }
}
