import '../widgets/user_image_picker.dart';
import 'package:flutter/material.dart';
import 'dart:io';

class UserImageScreen extends StatefulWidget {
  const UserImageScreen({Key? key}) : super(key: key);

  @override
  _UserImageScreenState createState() => _UserImageScreenState();
}

class _UserImageScreenState extends State<UserImageScreen> {
  File? _userImageFile;
  //bool pick = false;

  void _pickedImage(File? image) {
    _userImageFile = image;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select an Image'),
      ),
      body: Column(
        children: [
          Center(
            child: UserImagePicker(_pickedImage),
          )
        ],
      ),
    );
  }
}